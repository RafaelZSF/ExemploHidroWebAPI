﻿using MediatR;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace HidroWebAPI.Aplicacao
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services)
        {
            services.AddMediatR(Assembly.GetExecutingAssembly());
            //services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
            //services.AddTransient(typeof(IPipelineBehavior<,>), typeof(ValidateRequestBehaviour<,>));
            //services.AddTransient(typeof(IPipelineBehavior<,>), typeof(VerificaPermissaoUsuario<,>));

            //services.AddTransient(typeof(IPipelineBehavior<,>), typeof(RequestPostProcessorBehavior<,>));
            //services.AddTransient(typeof(IRequestPostProcessor<,>), typeof(ProcessadorAtividade<,>));

            return services;
        }
    }
}
