﻿using HidroWebAPI.Infraestrutura.Contexto;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using RotinaHidro.ExecucaoRotina;
using System;
using System.Net;
using System.Threading.Tasks;

namespace RotinaHidro
{
    public class Program
    {
        static void Main(string[] args)
        {
            if (!ServicePointManager.SecurityProtocol.HasFlag(SecurityProtocolType.Tls12))
            {
                ServicePointManager.SecurityProtocol = ServicePointManager.SecurityProtocol | SecurityProtocolType.Tls12;
            }

            ServiceProvider serviceProviderChesf = new ServiceCollection()
            .AddDbContext<HidroContexto>(opt => opt.UseSqlServer("Data Source=recwk8sqlsrv;Initial Catalog=HIDRO;PWD=D@m_csl_hId0;UID=SYSDAM_CONSULTA_HIDRO"))
            .BuildServiceProvider();

            HidroContexto contextChesf = serviceProviderChesf.GetRequiredService<HidroContexto>();

            //ServiceProvider serviceProviderPimenta = new ServiceCollection()
            //.AddDbContext<HidroContexto>(opt => opt.UseSqlServer("Data Source=10.10.1.6;Initial Catalog=SYSDAM_hom;PWD=3gZqz8Qt_8;UID=SYSDAM_hom"))
            //.BuildServiceProvider();

            //HidroContexto contextPimenta = serviceProviderPimenta.GetRequiredService<HidroContexto>();

            //Task.Factory.StartNew(() => new EnvioDadoHidrologico(contextChesf, contextPimenta).ExecutarRotina());

            new EnvioDadoInstrumento(contextChesf).ExecutarRotina();

            Console.WriteLine("FIM - Execução da Rotina");
            System.Threading.Thread.Sleep(5000);
        }
    }
}
