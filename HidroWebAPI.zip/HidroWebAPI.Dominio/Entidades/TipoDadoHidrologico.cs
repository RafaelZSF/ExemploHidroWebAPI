﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HidroWebAPI.Dominio.Entidades
{
    public class TipoDadoHidrologico
    {
        public int IdTipoDadoHidrologico { get; set; }
        public int IdEmpreendedor { get; set; }
        public string NomeTipoDado { get; set; }
    }
}
