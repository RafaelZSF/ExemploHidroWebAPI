﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HidroWebAPI.Dominio.Entidades
{
    public class UsuarioEmpreendedor
    {
        public int IdUsuario { get; set; }
        public int IdEmpreendedor { get; set; }
    }
}
